#!/usr/bin/env python3
"""
Step 1 of the deviseur-azure workflow.

Given a hardware spec (vCPU + RAM), propose several candidate Azure VM
flavors across families (Burstable / General / Memory / Compute) and show
their live price in a region, so the user can pick one.

Usage:
    python3 scripts/propose_flavors.py --vcpu 4 --ram 8 --region francecentral
"""

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from azure_lib import (  # noqa: E402
    load_catalog, query_vm_prices, organize_vm_prices,
    currency_symbol, target_vcpu, FAMILY_PREFERENCE, HOURS_PER_MONTH,
)


def rank_candidates(catalog, vcpu, ram, max_results):
    """Propose flavors under the sizing rule.

    **RAM must meet-or-exceed** the source (hard floor); **vCPU may sit just
    below** it — Azure has no odd-core sizes, so a 3 vCPU source floors to a
    2 vCPU target (see ``target_vcpu``). Candidates are ranked D-family first so
    the recommended "Standard" flavor heads the table, while still spreading
    across families for the user to compare.
    """
    target = target_vcpu(catalog, vcpu)
    fits = [s for s in catalog if s["ram_gib"] >= ram] or list(catalog)

    def key(s):
        over = max(0, s["vcpu"] - vcpu)       # cores above the source (discouraged)
        under = max(0, target - s["vcpu"])    # cores below the floored target (discouraged)
        return (over, under, FAMILY_PREFERENCE.get(s["family"], 9), s["ram_gib"], s["sku"])

    fits.sort(key=key)
    # De-duplicate by (family, vcpu, ram) keeping the best-ranked of each.
    seen = set()
    out = []
    for s in fits:
        k = (s["family"], s["vcpu"], s["ram_gib"])
        if k in seen:
            continue
        seen.add(k)
        out.append(s)
        if len(out) >= max_results:
            break
    return out


def main():
    p = argparse.ArgumentParser(description="Propose Azure VM flavors for a hardware spec")
    p.add_argument("--vcpu", "-v", type=int, required=True, help="Number of vCPUs (e.g. 4)")
    p.add_argument("--ram", "-m", type=float, required=True, help="RAM in GiB (e.g. 8)")
    p.add_argument("--region", "-r", default="francecentral", help="Azure region (default: francecentral)")
    p.add_argument("--currency", "-c", default="EUR", help="Currency code (default: EUR)")
    p.add_argument("--max", type=int, default=6, help="Max candidates to show (default: 6)")
    args = p.parse_args()

    sym = currency_symbol(args.currency)
    catalog = load_catalog()
    candidates = rank_candidates(catalog, args.vcpu, args.ram, args.max)

    if not candidates:
        print(f"No catalog flavors found near {args.vcpu} vCPU / {args.ram} GiB.")
        return

    print(f"Proposing flavors for ~{args.vcpu} vCPU / {args.ram:g} GiB in {args.region} "
          f"({args.currency})...\n")

    rows = []
    for c in candidates:
        prices = organize_vm_prices(query_vm_prices(c["sku"], args.region, args.currency))
        rows.append((c, prices))

    fam_label = {"B": "Burstable", "D": "General", "E": "Memory", "F": "Compute"}

    def mo(price):
        return "N/A" if price is None else f"{sym}{price * HOURS_PER_MONTH:,.2f}"

    print(f"## Flavor proposals — {args.vcpu} vCPU / {args.ram:g} GiB @ {args.region}\n")
    print("All prices are Linux, €/month per VM, across every commitment option.\n")
    print("| # | Flavor | Type | vCPU | RAM | PAYG/mo | Spot/mo | 1yr Res/mo | 3yr Res/mo |")
    print("|---|--------|------|------|-----|---------|---------|------------|------------|")
    for i, (c, pr) in enumerate(rows, 1):
        print(f"| {i} | {c['sku']} | {fam_label.get(c['family'], c['family'])} "
              f"| {c['vcpu']} | {c['ram_gib']} GiB "
              f"| {mo(pr['linux'])} | {mo(pr['spot'])} "
              f"| {mo(pr['reserved_1yr'])} | {mo(pr['reserved_3yr'])} |")

    print("\n> Sizing rule: **RAM meets-or-exceeds** your spec, while **vCPU may sit "
          "just below** it (Azure has no odd-core sizes — 3 vCPU → 2). The recommended "
          "D-family (\"Standard\" general-purpose) flavor is listed first; "
          "Burstable (B) is cheapest for low steady load, Memory (E) gives more RAM/vCPU.")
    print("> PAYG = pay-as-you-go on-demand; Spot = interruptible (deepest discount, "
          "no SLA); 1yr/3yr Res = reserved-instance commitment (amortized monthly). "
          "Some families (e.g. Spot/3yr on F or B) may show N/A where Azure has no such rate.")
    print(f"\n**Next:** pick a flavor, then run the quote:\n"
          f"`python3 scripts/query_quote.py --sku <Flavor> --region {args.region} "
          f"--disk-size <GiB> --disk-type premium-ssd`")


if __name__ == "__main__":
    main()
